import "./Middleinfo.css"
const Middleinfo = () => {
    return (
        <p className="middleinfo__text">
            UNDERPASS
        </p>
        
    );
};
export default Middleinfo;